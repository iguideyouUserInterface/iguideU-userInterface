<?php
//database configuration
$db_host ="localhost" ; 
$db_name = "blogyblogy"; 
$db_usr = "blogyblogyuser"; 
$db_pass = "123456";

//Establish a connection with MySQL and select the database to use
mysql_connect($db_host, $db_usr, $db_pass) or die("MySQL Error: " . mysql_error());
mysql_select_db($db_name) or die("MySQL Error: " . mysql_error());
?>