<?php

function hasLoggedOut(){
	if(isset($_POST['logout'])) {
            $_SESSION['user'] = false;
            if(isset($_SESSION['id'])) {
        	$_SESSION = array();
        	unset($_SESSION['username']);
        	unset($_SESSION['user']);
	        session_destroy();
            }
	}
}

function isLoggedIn() {
	 if (!isset($_SESSION['id'])) {
         
            require_once 'databaseconnect.php';

            if(!empty($_POST['username']) && !empty($_POST['password'])) {   // To "sanitize" our inputs
            
                $username = mysql_real_escape_string($_POST['username']);   // To protect MySQL injection
                $password = mysql_real_escape_string($_POST['password']);   // To protect MySQL injection
            
                $grabrow = mysql_query("SELECT * FROM user WHERE username = '$username'") or die
                ("MySQL Error: ".mysql_error());
                //if only one row was retrieved
                if (mysql_num_rows($grabrow) == 1) {
                     //create array from row field
                     $row = mysql_fetch_array($grabrow);

                     //store the users and email salt in a var
                     $salt = $row['usersalt'];
                     $email = $row['email'];

                     $combine = $email . $password . $salt;

                     //authenticate password with has function
                     $authenticatedpassword = sha1($combine);

                     // check database for username and the rehash pass
                     $checklogin = mysql_query("SELECT * FROM user WHERE username = '$username' AND password = '$authenticatedpassword'") or die
                    ("MySQL Error: ".mysql_error());

                    if(mysql_num_rows($checklogin) == 1) {

                        $id = mysql_result($checklogin, 0, 'id');
                        $_SESSION['id']= $id;
                        $_SESSION['username'] = $username;
                        $_SESSION['user'] = true;
                    } else {
                   
                        echo '<h1> Not authenticated boooo!</h1>';
                    }

                } else {
                    echo '<h1> you are not in database!</h1>';
                }
            }
	}
}

function displayTop() {
    ?>
    <div id="top">
        <h1>Welcome to Susan's Blog</h1>
		<div id="links">
			<a href='index.php'>Home</a>
			<a href='stats.php'>My Stats</a>
			<a href='signup.php'>Register</a> 
			<a href='rss.php'>RSS feed</a>
                </div>
    </div>

    <?
}


function displayNav(){
    ?>
    <div id="nav">
        <div id="form1">
        <?
        if (!isset($_SESSION['id'])) {
        	?>
        	<form name="form1" method="post" action="?">
            	<label for='username'>Username</label>
           	<input name="username" type="text" id="username" size="30" />
            	<label for='password'>Password</label>
            	<input name="password" type="password" id="password" size="30" />
                <br />
                <input type="submit" name="login" value="Log in" /> 
            </form>        	
           <?
        } else {
        	echo "<p>You are now logged in as: <br /> " . $_SESSION['username'] . "</p>";
        	?>
        	<form name="form1" method="post" action="?">
        		<input type="submit" name="logout" value="Log out" /> 
        	</form>
        	<?
        }
        ?>
            <form action='?' method='post'>
        	<label for='category'>Category</label>
        	<select name='category' >
                    <option value='all'>All</option>
                    <option value='chicken'>Chicken</option>
                    <option value='lion'>Lion</option>
                    <option value='snake'>Snake</option>
                    <option value='dog'>Dog</option>
                    <option value='cat'>Cat</option>
                </select>
                <input type='submit' name='categorySearch' value='Search!' />
            </form>
        </div>
    </div>
            
    <?
}
            
		
function displayContent() {
    if(isset($result)) {
        $title = "";
        $entry = "";
	while($row = mysql_fetch_array($result)) {
            echo "<div id= innerblog>" . "<h2>" . $row['title'] . "</h2>" .
            "<p>" . $row['entry'] ."</p>" . "<i>" . $row['blogdate'] . "</i>" .
            ' <a href="?">read more</a>' . "</div>";
	}
		
    } else {

        require_once 'databaseconnect.php';
        
        if(isset($_POST['categorySearch']) && !($_POST['category']=='all')) {
        	$chosenCategory = $_POST['category'];        	    	
        	$query = "SELECT * FROM blog
        	WHERE category='$chosenCategory'
        	ORDER BY blogdate DESC";
    		$result = mysql_query($query) or print 
    		("Can't select entry from table blog.<br />"
    		. $query . mysql_error());
    		$title = "";
    		$entry = "";	
        } else {
        	$query = "SELECT * FROM blog                  
        	ORDER BY blogdate DESC";
    		$result = mysql_query($query) or print 
    		("Can't select entry from table blog.<br />"
    		. $query . mysql_error());
    		$title = "";
    		$entry = "";
        }
        while($row = mysql_fetch_array($result)) {
            $var = $row['postid'];
            $queryTwo = "SELECT COUNT(idcomment) FROM comment WHERE blogid='$var'";
            $resultTwo = mysql_query($queryTwo) or die('Query failed: ' . mysql_error());
            while($rowTwo = mysql_fetch_array($resultTwo)){
            $var = $rowTwo[0];
	}
        echo "<div id= innerblog>" . "<h2>" . $row['title'] . "</h2>" .
            "<p>" . $row['entry'] ."</p>" . "<i>" . $row['blogdate'] . 
            " posted in category " . $row['category'] . "</i>"."</div>";

            ?>
           
            <ul class="accordion">
                <li id="acc">                    
                    <div id="comments<?= $row['postid'] ?>" ></div>
                    <h2>
                        <a href="#acc" id="commentButton<?= $row['postid'] ?>"
                         name ="showcomment" class="showcomment"  >Comments
                        </a>
                        <a href="#post<?postid?>" id="showNumComments<?= $row['postid'] ?>)">
                         <?echo $var ?></a>
                    </h2>
                </li>
                <div id="blog"></div>
            </ul>
            <ul class="comform">
                <li id="comf">
                    <a class="commentform" id="formcomment<?= $row['postid'] ?>" 
                    href="writecomment.php?postid=<?= $row['postid'] ?>">Write new comment</a>
                </li>
            </ul>
            <div class="writecomment" id="shownewcomment<?= $row['postid'] ?>">
                <?php printCommentForm($row['postid']);?>
            </div>

            <?php
                                       
            	if(isset($_POST['showcomment'])) {
                    include_once 'getcomment.php';
                }
                if(isset($_POST['commentform'])) {
                    include_once 'writecomment.php';
                }
	}
    }
} //close the displayContent() function


function displayForm() {
   if(isset($_SESSION['username'])) {
        $title = "";
        $entry = "";
         ?>
        <form action='?' method='post'>
            <label for='title'>Title</label>
            <input  type='text' name='title' id='title' value='<?=$title;?>' /><br />
            <label for='entry'>New Post</label>
            <input type='text' name='entry' id='entry' value='<?=$entry;?>' /><br />
            <label for='category'>Category</label>
            <select name='category'>
            	<option value='chicken'>Chicken</option>
            	<option value='lion'>Lion</option>
            	<option value='snake'>Snake</option>
            	<option value='dog'>Dog</option>
            	<option value='cat'>Cat</option>
            </select><br />
            <input type='hidden' name='postid' value='<?=$postid?>' />
            <input type='submit' name='new_entry' value='New Post!' />
        </form>

        <?php
        if(isset($_POST['new_entry'])) {
            $title = stripslashes($_POST['title']);
            $entry = stripslashes($_POST['entry']);
            $username = $_SESSION['username'];
            $postid = $_POST['postid'];
            $userid = $_SESSION['id'];
            $category = $_POST['category'];
         
            $query = "INSERT INTO blog
                   (title,entry,blogdate,userid,category)
                VALUES ('$title','$entry',NOW(), '$userid', '$category')";
            if(mysql_query($query)) {
                echo "Your post has been saved into the database!";
            } else {
                echo "Something is wrong!";
                }

	}
    }
}//close the displayForm() function



function statistics($currentUserId){
	
	require_once 'databaseconnect.php';

	$numberOfPosts=0;
	$numberOfComments=0;
	
	$query = "SELECT postid FROM blog WHERE userid = '$currentUserId'";
	$result = mysql_query($query) or die('Query failed: ' . mysql_error());
	
 	while($row = mysql_fetch_array($result)){
		$postid = $row[0];
		$numberOfPosts++;

					
		$queryTwo = "SELECT idcomment FROM comment WHERE blogid = '$postid'";
		$resultTwo = mysql_query($queryTwo) or die('Query failed: ' . mysql_error());
			
		while($rowTwo = mysql_fetch_array($resultTwo)){
			$commentid = $rowTwo[0];
			$numberOfComments++;
		}
	}	
	$avarage = ((1*($numberOfComments))/(1*($numberOfPosts)));
	
	echo "you have a total of " . $numberOfPosts . " number of posts, a total of " . 
	$numberOfComments . " number of comments with an avarage of " . 
	$avarage . "comments for each post.<br />";

        function numberOfComments($numberOfComments) {
            echo  $numberOfComments;
        }
	function getEntries($currentUserId) {

            $query = "SELECT * FROM blog
                  WHERE userid = '$currentUserId'";

            $result = mysql_query($query) or die('Query failed: ' . mysql_error());
            while($row = mysql_fetch_array($result)) {
                
                $rows[] = $row;
                $user_menu = "
                <a href='?delete={$row['postid']}'>Ta bort</a>
                <a href='?edit={$row['postid']}'>Redigera</a>
                ";
            
                echo "
                <p>postid:{$row['postid']}</p>
                <p>posttitle:{$row['title']}</p>
                <p>entry:{$row['entry']}</p>
                <p>{$row['blogdate']}</p>
                <p>userid:{$row['userid']}</p>
                $user_menu
                <hr />
                ";
            }
            $user_menu = "";
	}
        function deleteEntry($delete_id){
            $query = "DELETE FROM blog WHERE postid = $delete_id";
            $result = mysql_query($query);
            return $result;
        }
        function printEntryForm($title="",$entry="",$postid=""){
    	?>
    	<form action='?' method='post'>
            <label for='title'>Title</label>
            <input type='text' name='title' id='title' value='<?=$title;?>' /><br />
            <label for='entry'>Entry</label>
            <textarea name='entry' id='entry' value='<?=$entry;?>'></textarea>
            <input type='hidden' name='postid' value='<?=$postid?>' />
            <input type='submit' name='edit_entry' value='Send Post!' />
        </form>
        <hr />
        <?php
        }
    
        function getEntry($edit_id){
            $query = "SELECT * FROM blog WHERE postid=$edit_id LIMIT 1";
            $result = mysql_query($query) or die(mysql_error());
            return mysql_fetch_assoc($result);
        }
    
        function addEntry($title,$entry,$postid){
            if($postid) {
                $query = "UPDATE blog
                SET title = '$title',
                entry = '$entry'
                WHERE postid = $postid
                ";
            } else {
                $query = "INSERT INTO blog
                (title,entry,postid,date)
                VALUES ('$title','$entry','$postid',NOW())
          	";
            }

            if(mysql_query($query)){
                echo "Your post has been saved!";
            } else {
                echo "Something went wrong booooo!";
            }
        }
}//close the statistics() function
?>