-- phpMyAdmin SQL Dump
-- version 3.3.9.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 20, 2012 at 02:50 PM
-- Server version: 5.5.9
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `userDb`
--

-- --------------------------------------------------------

--
-- Table structure for table `document`
--

CREATE TABLE `document` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `docid` varchar(100) NOT NULL,
  `userid` varchar(100) NOT NULL,
  `docname` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `document`
--

INSERT INTO `document` VALUES(1, '1', '5', 'Tapas restaurant');
INSERT INTO `document` VALUES(2, '2', '5', 'Tequila Sunrise Bar');
INSERT INTO `document` VALUES(3, '3', '7', 'Grand Hotel Stockholm');
INSERT INTO `document` VALUES(4, '4', '6', 'J Restaurant');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `usersalt` varchar(255) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` VALUES(4, 'test1', '7c1d3219a713ff814cf0c486bae65261b1734c7c', 'test@gmail.com', '11459334264f5b3a679ff62', '2012-03-10 12:26:31');
INSERT INTO `user` VALUES(5, 'susan', 'adc174c69425327fbad08a183828c07f259a1a09', 'susan.sarabia007@gmail.com', '9910891514f5b3abf5ac9c', '2012-03-10 12:27:59');
INSERT INTO `user` VALUES(6, 'filip', '5e001510af2e839bb261ed95a437ed5bf398b62d', 'flaca007@gmail.com', '653087204f5c9a84cf20c', '2012-03-11 13:28:52');
INSERT INTO `user` VALUES(7, 'erik', 'df6dfcbf00725097e2f556447bf6e1b95f59ce35', 'erik@gmail.com', '12850239744f686fd849d14', '2012-03-20 12:54:00');
